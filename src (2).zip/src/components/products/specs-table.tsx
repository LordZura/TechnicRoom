import { getLocaleFromCookie } from '@/lib/i18n/locale';
import { getDictionary } from '@/lib/i18n/dictionaries';
import { getProductOptionLabel } from '@/lib/product-options';

type SpecRow = { label: string; value: unknown };

const specKeys = [
  'color',
  'has_fresh_air_intake',
  'recommended_area',
  'cooling_power',
  'heating_power',
  'cooling_consumption',
  'heating_consumption',
  'eer_cop',
  'freon_type_amount',
  'operating_temperature',
  'indoor_unit_size',
  'indoor_unit_weight',
  'outdoor_unit_size',
  'outdoor_unit_weight',
  'noise_level',
  'pipe_size'
] as const;

export function SpecsTable({ product }: { product: Record<string, unknown> }) {
  const locale = getLocaleFromCookie();
  const t = getDictionary(locale);

  const rows = specKeys
    .map((key) => ({
      label: t.productSpecLabels[key],
      value: key === 'has_fresh_air_intake'
        ? product[key] === true
          ? t.productSpecLabels.has_fresh_air_intake
          : null
        : key === 'color' && typeof product[key] === 'string'
          ? getProductOptionLabel('color', product[key] as string, locale)
        : product[key]
    }))
    .filter((row) => row.value !== null && row.value !== undefined && row.value !== '');
  const customRows: SpecRow[] = Array.isArray(product.custom_specs)
    ? product.custom_specs
        .flatMap((item) => {
          if (!item || typeof item !== 'object') return [];

          const spec = item as { name?: unknown; value?: unknown };
          const localizedSpec = item as { name_ka?: unknown; value_ka?: unknown };
          const label = locale === 'ka' && typeof localizedSpec.name_ka === 'string' && localizedSpec.name_ka.trim()
            ? localizedSpec.name_ka
            : spec.name;
          const value = locale === 'ka' && typeof localizedSpec.value_ka === 'string' && localizedSpec.value_ka.trim()
            ? localizedSpec.value_ka
            : spec.value;

          if (typeof label !== 'string' || !label.trim()) return [];
          if (value === null || value === undefined || value === '') return [];

          return [{ label: label.trim(), value }];
        })
    : [];
  const allRows = [...rows, ...customRows];

  if (!allRows.length) return null;

  return (
    <>
      <div className="grid grid-cols-2 gap-2.5 sm:hidden">
        {allRows.map((row) => (
          <div
            key={row.label}
            className="rounded-2xl border border-brand-line bg-brand-ivory px-4 py-3 shadow-soft"
          >
            <p className="text-[11px] uppercase tracking-[0.16em] text-brand-700/75">
              {row.label}
            </p>
            <p className="mt-1.5 text-sm font-medium text-brand-espresso">
              {String(row.value)}
            </p>
          </div>
        ))}
      </div>

      <dl className="hidden overflow-hidden rounded-[1.4rem] border border-brand-line bg-brand-ivory shadow-soft sm:block">
        {allRows.map((row, idx) => (
          <div
            key={row.label}
            className={`grid gap-2 px-4 py-3 sm:grid-cols-[1.3fr_1fr] sm:items-start sm:px-5 ${
              idx % 2 === 0 ? 'bg-brand-ivory' : 'bg-brand-50'
            } ${idx !== allRows.length - 1 ? 'border-b border-brand-sand' : ''}`}
          >
            <dt className="text-sm font-medium text-brand-700/85">{row.label}</dt>
            <dd className="text-sm text-brand-espresso">{String(row.value)}</dd>
          </div>
        ))}
      </dl>
    </>
  );
}
