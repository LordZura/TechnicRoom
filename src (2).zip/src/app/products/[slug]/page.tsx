import Link from 'next/link';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { ProductGallery } from '@/components/products/product-gallery';
import { ShareButton } from '@/components/products/share-button';
import { SpecsTable } from '@/components/products/specs-table';
import { ProductCard } from '@/components/products/product-card';
import { Reveal } from '@/components/ui/reveal';
import { getLocaleFromCookie } from '@/lib/i18n/locale';
import { getDictionary } from '@/lib/i18n/dictionaries';
import { getProductBySlug, getProducts, pickTranslation } from '@/lib/supabase/queries';
import { getProductOptionLabel } from '@/lib/product-options';
import { slugify } from '@/lib/slug';
import {
  breadcrumbJsonLd,
  buildProductMetadata,
  getProductDescription,
  getProductName,
  productJsonLd
} from '@/lib/seo';

function formatPrice(price: number) {
  return `₾${new Intl.NumberFormat('en-US', {
    minimumFractionDigits: Number.isInteger(price) ? 0 : 2,
    maximumFractionDigits: 2
  }).format(price)}`;
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const product = await getProductBySlug(params.slug);

  // Keep unpublished or missing products out of indexes.
  if (!product) {
    return {
      title: 'Product not found',
      robots: { index: false, follow: false }
    };
  }

  return buildProductMetadata(product);
}

export default async function ProductDetailsPage({ params }: { params: { slug: string } }) {
  const locale = getLocaleFromCookie();
  const t = getDictionary(locale);
  const product = await getProductBySlug(params.slug);
  if (!product) return notFound();
  const translation = pickTranslation(product, locale);
  const productName = getProductName(product, locale);
  const productDescription = getProductDescription(product, locale);
  const numericPrice = product.price === null ? null : Number(product.price);
  const compareLabel = locale === 'ka' ? 'შედარება' : 'Compare to';
  const categoryLabel = product.category ? getProductOptionLabel('category', product.category, locale) : null;
  const categoryHref = product.category ? `/products/category/${slugify(product.category)}` : null;
  const brandHref = `/products/brand/${slugify(product.brand)}`;
  const availabilityLabel = locale === 'ka' ? 'ხელმისაწვდომია' : 'Available';
  const statusText = locale === 'ka' ? 'სტატუსი' : 'Status';
  const overviewLabel = locale === 'ka' ? 'პროდუქტის აღწერა' : 'Product overview';
  const categoryText = locale === 'ka' ? 'კატეგორია' : 'Category';
  const brandText = locale === 'ka' ? 'ბრენდი' : 'Brand';
  const homeText = locale === 'ka' ? 'მთავარი' : 'Home';
  const productsText = locale === 'ka' ? 'პროდუქტები' : 'Products';

  const related = (await getProducts()).filter((item) => item.slug !== product.slug && item.brand === product.brand).slice(0, 4);
  const schema = [
    productJsonLd(product, locale),
    breadcrumbJsonLd([
      { name: homeText, url: '/' },
      { name: productsText, url: '/products' },
      { name: productName, url: `/products/${product.slug}` }
    ])
  ];

  return (
    <div className="space-y-7 pb-20 sm:space-y-8 sm:pb-0">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
      <nav aria-label="Breadcrumb" className="pt-3 text-xs text-brand-700/75 sm:pt-4">
        <ol className="flex flex-wrap items-center gap-1.5">
          <li><Link href="/" className="hover:text-brand-brown">{homeText}</Link></li>
          <li aria-hidden="true">/</li>
          <li><Link href="/products" className="hover:text-brand-brown">{productsText}</Link></li>
          <li aria-hidden="true">/</li>
          <li className="font-medium text-brand-espresso">{productName}</li>
        </ol>
      </nav>
      <section className="grid gap-5 lg:grid-cols-[1.06fr_0.94fr] lg:gap-6">
        <Reveal>
          <ProductGallery images={product.images} fallbackAlt={productName} locale={locale} />
        </Reveal>
        <Reveal delay={120}>
          <div className="tr-surface space-y-4 p-4 sm:p-6">
            <Link href={brandHref} className="inline-flex text-[11px] uppercase tracking-[0.2em] text-brand-600/80 hover:text-brand-brown">
              {product.brand}
            </Link>
            <h1 className="text-2xl font-bold leading-tight sm:text-3xl">{productName}</h1>
            <p className="text-sm text-brand-700/85">{t.product.modelLabel}: {product.model}</p>
            <dl className="grid gap-2 rounded-2xl border border-brand-line bg-brand-ivory p-3 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-[11px] uppercase tracking-[0.14em] text-brand-700/75">{brandText}</dt>
                <dd className="mt-1 font-medium text-brand-espresso">
                  <Link href={brandHref} className="hover:text-brand-brown hover:underline">{product.brand}</Link>
                </dd>
              </div>
              {categoryLabel && categoryHref && (
                <div>
                  <dt className="text-[11px] uppercase tracking-[0.14em] text-brand-700/75">{categoryText}</dt>
                  <dd className="mt-1 font-medium text-brand-espresso">
                    <Link href={categoryHref} className="hover:text-brand-brown hover:underline">{categoryLabel}</Link>
                  </dd>
                </div>
              )}
              <div>
                <dt className="text-[11px] uppercase tracking-[0.14em] text-brand-700/75">SKU</dt>
                <dd className="mt-1 font-medium text-brand-espresso">{product.model}</dd>
              </div>
              <div>
                <dt className="text-[11px] uppercase tracking-[0.14em] text-brand-700/75">{statusText}</dt>
                <dd className="mt-1 font-medium text-brand-espresso">{availabilityLabel}</dd>
              </div>
            </dl>
            {numericPrice !== null && Number.isFinite(numericPrice) && (
              <p className="text-xl font-semibold text-brand-brown">
                {formatPrice(numericPrice)}
              </p>
            )}
            <section className="space-y-2">
              <h2 className="text-base font-semibold">{overviewLabel}</h2>
              <p className="text-sm text-brand-800/85 sm:text-base">{productDescription}</p>
            </section>

            <div className="hidden gap-3 sm:flex">
              <ShareButton label={t.product.share} copiedLabel={t.product.copied} />
              <Link href="/contact" className="tr-btn-primary">{t.product.contactAdvisor}</Link>
            </div>

            {translation?.features && (
              <div className="rounded-2xl border border-brand-line bg-brand-cream p-4 transition hover:border-brand-gold/70">
                <h2 className="mb-2 text-base font-semibold">{t.product.features}</h2>
                <p className="text-sm text-brand-800/85">{translation.features}</p>
              </div>
            )}

            <div className="flex justify-end border-t border-brand-line pt-4">
              <Link href={`/compare?product=${product.slug}`} className="tr-btn-ghost">{compareLabel}</Link>
            </div>
          </div>
        </Reveal>
      </section>

      <Reveal className="space-y-3" delay={120}>
        <h2 className="tr-section-title">{t.product.specs}</h2>
        <SpecsTable product={product} />
      </Reveal>

      {related.length > 0 && (
        <Reveal className="space-y-3.5" delay={180}>
          <h2 className="tr-section-title">{t.product.related}</h2>
          <div className="-mx-1.5 flex snap-x snap-mandatory gap-3 overflow-x-auto px-1.5 pb-2 no-scrollbar sm:mx-0 sm:grid sm:grid-cols-2 sm:gap-4 sm:overflow-visible sm:px-0 sm:pb-0 xl:grid-cols-4">
            {related.map((item, index) => (
              <Reveal key={item.id} delay={index * 70} className="min-w-[84%] snap-start sm:min-w-0">
                <ProductCard product={item} locale={locale} />
              </Reveal>
            ))}
          </div>
        </Reveal>
      )}

      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-brand-line bg-brand-ivory/95 px-3.5 py-2 backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-7xl items-center gap-2.5">
          <ShareButton label={t.product.share} copiedLabel={t.product.copied} />
          <Link href="/contact" className="tr-btn-primary flex-1">{t.product.contactAdvisor}</Link>
        </div>
      </div>
    </div>
  );
}
